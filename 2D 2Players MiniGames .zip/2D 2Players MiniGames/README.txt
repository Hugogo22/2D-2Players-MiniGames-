Open "Minigames menu.jar"
Enjoy :)


Pong by Nicolas
Tic Tac Toe by Hugo
Connect 4 by Clément