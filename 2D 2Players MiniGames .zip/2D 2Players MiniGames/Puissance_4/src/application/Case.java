package application;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Case extends ImageView{

	private static Image rouge = new Image("PionR.png"); // image du pion rouge en static
	private static Image jaune = new Image("PionJ.png"); // image du pion jaune en static


	//vide = 0 ; rouge = 1 ; jaune = 2;
	private int statut;

	public Case(){
		this.statut = 0;
	}

	public void set(int j){
		this.setImage(j == 1 ? rouge : jaune); // si le statut de la casse est = a 1 alors le pion et
		this.statut = j;
	}


	public int getStatut(){ // permet de savoir si la case est vide ou pas
		return statut;
	}

}
