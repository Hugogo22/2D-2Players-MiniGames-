package application;

import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.When;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.StrokeType;
import javafx.scene.text.Font;
import javafx.stage.Stage;


public class Main extends Application {

	private static int precedent; //variable
	private static int nbTour; //variable

	private Case[][] cases; //variable

	public void start(Stage primaryStage) {
		try {

			int N = 4; // nb de pion � aligner pour gagner
			int C = 7; // nb de colonnes
			int L = 6; // nb de lignes



			//couleur de fond:
			Color couleurFond = Color.GRAY;


			Group root = new Group();
			Scene scene = new Scene(root,700,600 + 100); // ouverture d'une fennetre de 700 par 600 + 100 pour du texte
			scene.setFill(couleurFond); // on applique la couleur de fond � la scene

			When w = Bindings.when((scene.widthProperty().divide(scene.heightProperty())).greaterThan(7.0/6.0)); // condition sur les propri�t�s de la fenetre

			//creation de notre plateau de jeu
			Rectangle r = new Rectangle(0, 0, 700, 600); // creation d"un rectangle de 700 par 600 au coordonn� indiqu�
			LinearGradient lg = new LinearGradient(0,0,1,1, true, CycleMethod.NO_CYCLE, new Stop(0, Color.web("#1A54BF")), new Stop(0.5, Color.rgb(0, 0, 100)), new Stop(1, Color.web("#2967DA"))); // on applique 2 bleu degrad� different � notre plateau de jeu
			r.setFill(lg);
			root.getChildren().addAll(r);

			r.heightProperty().bind(w.then(scene.heightProperty().subtract(100)).otherwise(r.widthProperty().multiply(6.0/7.0))); // la hauteur du plateau est li� � la hauteur de la fennetre dans un cas et sinon � la longueur de la scene
			r.widthProperty().bind(w.then(r.heightProperty().multiply(7.0/6.0)).otherwise(scene.widthProperty())); //IDEM mais pour la largeur

			// Cr�ation des emplacements VISIBLE pour mettre les jeton
			for(int i = 0 ; i < L ; i++){ // pour cahque ligne
				for (int j = 0 ; j < C ; j++){ // pour chaque colonne
					Circle c = new Circle(5 +45 + 100*j, 5+45 + 100*i, 45); // creation d'un rond
					c.setFill(couleurFond); // le rond prend la couleur de fond
					c.radiusProperty().bind(r.heightProperty().divide(12).subtract(5)); // le rayon est lier a la taille de du plateau divis� par 6 car si 6 et par 2 car rayon - 5 pixels pour laisser une place entre chauqe trou
					c.centerXProperty().bind(r.widthProperty().divide(7).multiply(j+0.5));// la possition du X est lier a la taille du plateau divis� par 7 (7 colonnes) fois J +0.5 pour etre au centre le la colonne
					c.centerYProperty().bind(r.heightProperty().divide(6).multiply(i+0.5)); // IDEM mais pour Y avec les lignes cette fois
					root.getChildren().add(c);
				}
			}


			//cr�ation des amplacement des pions
			cases = new Case[7][6]; // tableau de 7 pat 6


			for(int i = 0 ; i < L ; i++){ // pour chaque ligne
				for (int j = 0 ; j < C ; j++){ // pour chaque colonne
					cases[j][i] = new Case(); // nouvelle case
					cases[j][i].layoutXProperty().bind(r.widthProperty().divide(7).multiply(j)); // meme systeme que pour le cercle mais sans les -0.5
					cases[j][i].layoutYProperty().bind(r.heightProperty().divide(6).multiply(i)); //IDEM
					cases[j][i].fitHeightProperty().bind(r.heightProperty().divide(6)); // definir une hauteur pour la case, celle du plateau divis� par le nb de lignes
					cases[j][i].fitWidthProperty().bind(r.widthProperty().divide(7)); // definir une largueur pour la case , celle du plateau divis� par le nb de colonnes


					root.getChildren().add(cases[j][i]);
				}
			}



			//tous les textes:
			Label tour = new Label("Tour 1"); // texte pour les tours
			tour.setTextFill(Color.web("#3C7EF8")); // defini la couleur du texte
			tour.setFont(Font.font("Copper Black", scene.getHeight() / 20)); // defini le type de police, et la taille
			tour.setLayoutX(100);
			tour.layoutYProperty().bind(r.heightProperty());


			Label joueur = new Label("Au joueur rouge de jouer"); // textes pour dire a qui de jouer
			joueur.setTextFill(Color.web("#EEE839"));
			joueur.setFont(Font.font("Copper Black", scene.getHeight() / 20));
			joueur.setLayoutX(300);
			joueur.layoutYProperty().bind(r.heightProperty());

			Label victoire = new Label(""); // texte pour dire si il y a une victoire ou egalit�
			victoire.setTextFill(Color.web("#EA67F7"));
			victoire.setFont(Font.font("Copper Black", scene.getHeight() / 20));
			victoire.setLayoutX(300);
			victoire.layoutYProperty().bind(r.heightProperty());
			victoire.setVisible(false);

			scene.heightProperty().addListener(e->{ // permet de redifir la taille de la police quand le fenetre est modifi�
				tour.setFont(Font.font("Copper Black", scene.getHeight() / 20));
				joueur.setFont(Font.font("Copper Black", scene.getHeight() / 20));
				victoire.setFont(Font.font("Copper Black", scene.getHeight() / 20));
			});



			root.getChildren().addAll(tour, joueur, victoire);


			//Un rectangle pour voir notre selection
			Rectangle[] rects = new Rectangle[C]; // tableu de rectangle
			for(int i = 0 ; i < C ; i++){ // pour chaque colonnes
				rects[i] = new Rectangle(0, 0, 10, 10);
				rects[i].layoutXProperty().bind(r.widthProperty().divide(C).multiply(i)); // la largueur du rectangle est li� � celle du plateau diviser par le nb de colonnes
				rects[i].heightProperty().bind(r.heightProperty());
				rects[i].widthProperty().bind(r.widthProperty().divide(C));
				rects[i].setFill(Color.TRANSPARENT); // applique la couleur transparent
				rects[i].setStroke(Color.ORANGE); // couleur de la bordure du rectangle
				rects[i].setStrokeType(StrokeType.INSIDE); // permet de faire en sorte que la bordure soit � l'interieur du rectangle
				rects[i].setStrokeWidth(4); // taille de la bordure du rectangle
				rects[i].setVisible(false);

				root.getChildren().addAll(rects[i]);
			}


			//selections:

			Rectangle r2 = new Rectangle(0,0,10,10);
			r2.heightProperty().bind(r.heightProperty()); // meeme hauteur de rectangle d'avant
			r2.widthProperty().bind(r.widthProperty()); // IDEM pouyr largueur
			r2.setFill(Color.TRANSPARENT);
			root.getChildren().addAll(r2);

			precedent = -1;
			r2.setOnMouseMoved(e -> { // ce rectangle va nous permttre de savoir ou se trouve noter sourie et donc d'afficher le bon rectangle de selection

					int val = (int)(e.getX() / (r.getWidth() / C));
					if(val != precedent){
						rects[val].setVisible(true);
						if(precedent > -1)
							rects[precedent].setVisible(false);
					}
					precedent= val;

			});



			nbTour = 1;

			//cliqu� bande de salope cliqu�:
			r2.setOnMouseClicked(e -> {


				int colonne = (int)(e.getX() / (r.getWidth() / C)); // detecte la colonne

				//placement du jeton:
				if(cases[colonne][0].getStatut() == 0 && !victoire.isVisible()){ // place une jeton SI ET SEULEMENT SI la dernier case de la colonne n'ait pas rempli

					int rang = L-1;
					while(cases[colonne][rang].getStatut() != 0){
						rang--;
					}
					cases[colonne][rang].set(nbTour%2==1 ? 1 : 2);


					//conditon de victoire:


					//couleur en cours:
					int couleur = (nbTour%2==1 ? 1 : 2);
					//nombre align�s maximal:
					int max = 0;
					int x; int y;
					int somme;

					// DETECTION DE LA VICTOIRE
					//-->  diagonale Haut gaucher vers bas droit
					x = colonne; y = rang; somme=-1;
					while(y >= 0 && x >= 0 && cases[x][y].getStatut() == couleur){ y--; x--; somme++;}
					x = colonne; y = rang;
					while(y < L && x < C && cases[x][y].getStatut() == couleur){ y++; x++; somme++;}
					if(somme > max) max= somme;

					//-->  diagonale Haut droit vers bas gauche
					x = colonne; y = rang; somme=-1;
					while(y >= 0 && x < C && cases[x][y].getStatut() == couleur){ y--; x++; somme++;}
					x = colonne; y = rang;
					while(y < L && x >= 0 && cases[x][y].getStatut() == couleur){ y++; x--; somme++;}
					if(somme > max) max= somme;

					//-->  � la verticale:
					x = colonne; y = rang; somme=-1;
					while(y >= 0 && cases[x][y].getStatut() == couleur){ y--; somme++;}
					y = rang;
					while(y < L && cases[x][y].getStatut() == couleur){ y++; somme++;}
					if(somme > max) max= somme;

					//-->  � l'horizontale:
					x = colonne; y = rang; somme=-1;
					while(x >= 0 && cases[x][y].getStatut() == couleur){ x--; somme++;}
					x = colonne;
					while(x < C && cases[x][y].getStatut() == couleur){ x++; somme++;}
					if(somme > max) max= somme;


					if(max >= N){
						joueur.setVisible(false);
						victoire.setVisible(true);
						victoire.setTextFill(couleur == 1 ? Color.RED : Color.YELLOW);
						victoire.setText("Victoire du joueur " + (couleur == 1 ? "ROUGE" : "JAUNE")); // message de victoire
						nbTour--;
					}







					nbTour++;



					if(nbTour > C*L && max < N){
						joueur.setVisible(false);
						victoire.setVisible(true);
						victoire.setText("C'est une �galit� !"); // message d'�galit�
						nbTour--;
					}


					tour.setText("Tour " + nbTour);
					joueur.setText("Au joueur " + (nbTour%2 == 1 ? "rouge" : "jaune") + " de jouer"); // texte pour dire a qui de jouer

				}


			});









			primaryStage.setTitle("Le puissance 4"); // nom de la fennetre ouverte
			primaryStage.setScene(scene);
			primaryStage.show();



		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
