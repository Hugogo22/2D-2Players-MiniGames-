package com.HCN.menu.Pong;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

import com.HCN.menu.Game;

public class fenetrepong extends Game implements KeyListener {
	
	static boolean startGame = false;
	public static panelpong panel = new panelpong();
	
	
	public void init() {
		//Cr�ation de la fen�tre
		JFrame frame= new JFrame();
		frame.setTitle("Pong");
		frame.setSize(800, 600);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				fenetrepong.this.interrupt();
				frame.dispose();
			}
		});
		frame.setVisible(true);
		frame.setContentPane(panel);
		frame.addKeyListener(this);
		Balle(); //bonjour
	}
	
	

	private static int speedx = 1;
	private static int speedy = 1;
	
	private static void Balle() {
		int x = panel.getXBalle();
		int y = panel.getYBalle();
		boolean backX = false;
		boolean backY = false;

		//ex�cution  du mouvement de la balle
		while(true) {
			//On va chercher les coordon�es de la balle
			x = panel.getXBalle();
			y = panel.getYBalle();
			//On "cr��" les collisions entre les murs et la balle,
			//et on la fait rebondir
			if (x < 25) {
				backX = false;
			}
			if (x > panel.getWidth() - 40) {
				backX = true;
			}
			if (y < 1) {
				backY = false;
			}
			if (y > panel.getHeight() - 25) {
				backY = true;
			}
			if(!backX)
				panel.setXBalle(x + speedx);
			else   
				panel.setXBalle(x - speedx);
			
			if(!backY)
				panel.setYBalle(y + speedy);
			else
				panel.setYBalle(y - speedy);
			panel.setJ2Y(y - 30);
			panel.repaint();
			
			try {
				Thread.sleep(5);
			} catch (InterruptedException e) {
				return;
			}
		}
	}


	//Permet d'ex�cuter le programme lorsque la barre espace est press�
	public void keyPressed(KeyEvent e) {
		System.out.println(e.getKeyCode());
		if(e.getKeyCode() == KeyEvent.VK_SPACE) fenetrepong.startGame = true;
	}


	@Override
	public void keyReleased(KeyEvent e) {
		
	}


	@Override
	public void keyTyped(KeyEvent e) {
		
	}

}
