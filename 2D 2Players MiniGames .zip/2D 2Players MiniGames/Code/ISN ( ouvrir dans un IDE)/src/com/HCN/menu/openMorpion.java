package com.HCN.menu;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

public class openMorpion extends Game {


	public void init() {
		try {
		    Desktop.getDesktop().open(new File("Le_Puissance_4.jar"));
		} catch (IOException ex) {
		    System.out.println(ex.getMessage());
		}

	}

}
