package com.HCN.menu.Pong;

import java.awt.*;
import javax.swing.*;

import com.HCN.menu.Main;

@SuppressWarnings("serial")
public class panelpong extends JPanel {
	
	private int J1X;
	private int J1Y;
	private int J2X;
	private int J2Y;
	private int XBalle;
	private int YBalle;
	public panelpong() {
		J1X = 10;
		J1Y = 260;
		J2X = 768;
		J2Y = 260;
		XBalle = 385;
		YBalle = 285;
		this.setFocusable(true);
		this.requestFocusInWindow();
		this.addKeyListener(new PlayablePaddle());
	}
	public void paintComponent(Graphics g) {
		//On dessine le conteneur
		g.setColor(Main.color);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		g.setColor(Color.WHITE);
		g.fillRoundRect(J1X, J1Y, 15, 80, 10, 10);
		g.fillRoundRect(J2X, J2Y, 15, 80, 10, 10);
		g.setColor(Color.CYAN);
		g.fillOval(XBalle, YBalle, 15, 15);
		
	}
	//Fonctions permettant de partager les coordonn�es de la balle et des raquettes
	//des joueurs avec les autres classes
	public int getJ1X() {
		return J1X;
	}
	public int getJ1Y() {
		return J1Y;
	}
	public void setJ1X(int X) {
		this.J1X = X;
	}
	public void setJ1Y(int Y) {
		this.J1Y = Y;
	}
	public int getJ2X() {
		return J2X;
	}
	public int getJ2Y() {
		return J2Y;
	}
	public void setJ2X(int X2) {
		this.J2X = X2;
	}
	public void setJ2Y(int Y2) {
		this.J2Y = Y2;
	}
	public int getXBalle() {
		return XBalle;
	}
	public int getYBalle() {
		return YBalle;
	}
	public void setXBalle(int XB) {
		this.XBalle = XB;
	}
	public void setYBalle(int YB) {
		this.YBalle = YB;
	}
}