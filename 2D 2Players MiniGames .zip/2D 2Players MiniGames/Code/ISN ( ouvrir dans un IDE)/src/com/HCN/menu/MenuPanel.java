package com.HCN.menu;

import javax.swing.*;

import com.HCN.menu.Morpion.mainMorpion;
import com.HCN.menu.Pong.fenetrepong;

import java.awt.*;
import java.awt.event.*;

@SuppressWarnings("serial")
public class MenuPanel extends JPanel {

	
	
	@SuppressWarnings("unused")
	public void paintComponent(Graphics g) {
		//Cr�ation du conteneur
		g.setColor(Main.color);
		g.fillRect(0, 0, Main.Window_W, Main.Window_H);
		g.setColor(Color.RED);
		g.drawString("Two Player Game", Main.Window_W / 2 - 50 , Main.Window_H / 2 - 300);
		
		//Cr�ation des boutons
		JButton buttonP4 = makebutton("Puissance 4 (1V1)", -220, 0, new openMorpion());
		JButton buttonPong = makebutton("Pong", 0, 0, new fenetrepong());
		JButton buttonMorpion = makebutton("Morpion", 220, 0, new mainMorpion());
		JButton buttonleave = makebutton("Quitter", 0, 200, new LeaveMenu());

	}
	//Fonction cr�ant des boutons plus facilement (afin de ne pas b�tement recopier plusieurs m�mes lignes)
										  //Position par rapport au centre
	public JButton makebutton(String name, int PosX, int PosY, Game game) {
		JButton button = new JButton(name);
		button.setSize(200, 90);
		button.setBackground(Color.LIGHT_GRAY);
		button.setLocation(Main.Window_W / 2 - 100 + PosX, Main.Window_H / 2 - 45 + PosY);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				game.start();
			}
		});
		Main.frame.add(button);
		return button;
	}
}
