package com.HCN.menu.Morpion;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

@SuppressWarnings("serial")
public class game extends JFrame{
	
	//D�claration des variables
	private static JFrame Mframe;
	private static JPanel MSidePanel;
    private static JPanel MMainPanel;
    public static final int MWindow_H = 700;
    public static final int MWindow_W = 900;
    private static Mcases listeCases[][] = new Mcases[3][3];
    private static int playing = 0;
    private static JLabel joueur;
    private static JButton rejouer;
    private static JButton quitter;

    public game() {
    	initWindow();
    }
    
	private static void initWindow() {
		
		playing = 0;
		//Cr�ation de la fen�tre, MMainPanel est la partie jouable et MSidePanel l'affichage sur le bord droit.
		MSidePanel = new JPanel();
		MMainPanel = new JPanel();
		Mframe = new JFrame();
		Mframe.setSize(MWindow_W, MWindow_H);
		Mframe.setResizable(false);
		Mframe.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		Mframe.setTitle("Morpion");
		Mframe.setVisible(true);
		Mframe.setLocationRelativeTo(null);
		Mframe.setLayout(new GridBagLayout());
		MSidePanel.setSize(200, 700);
		MSidePanel.setBackground(Color.DARK_GRAY);
		MSidePanel.setLayout(null);
		
		joueur = new JLabel("Tour du joueur 1");
		joueur.setForeground(Color.white);
		joueur.setBounds(40, 50, 150, 50);
		MSidePanel.add(joueur);
		
		//Cr�ation du boutton "Quitter"
		quitter = new JButton("Quitter");
		quitter.setBounds(30, 400, 120, 50);
		quitter.setBackground(Color.white);
		quitter.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Mframe.dispatchEvent(new WindowEvent(Mframe, WindowEvent.WINDOW_CLOSING));
				return;
			}
		});
		MSidePanel.add(quitter);
		
		MMainPanel.setSize(700, 700);
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.VERTICAL;
		gbc.ipadx = 700;
		gbc.ipady = 645;
		Mframe.add(MMainPanel, gbc);
		gbc.ipadx = 200;
		Mframe.add(MSidePanel, gbc);
		//Cr�ation du tableau du morpion
		MMainPanel.setLayout(new GridLayout(3,3));
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				listeCases[i][j] = new Mcases(i,j);
				MMainPanel.add(listeCases[i][j]);
			}
		}
	}
	
	//Remplissage des cases et de leurs variables
	public static void CaseClicker(int x, int y) {
		listeCases[x][y].player1 = false;
		listeCases[x][y].player2 = false;
		//Si le joueur 1 joue
		if (playing%2 == 0 && listeCases[x][y].rempli == "0") {
			listeCases[x][y].player1 = true;
			listeCases[x][y].repaint();
			listeCases[x][y].rempli = "1";
			playing++;
			joueur.setText("Tour du joueur 2");
		}
		//Si le joueur 2 joue
		else if (playing%2 == 1 && listeCases[x][y].rempli == "0"){
			listeCases[x][y].player2 = true;
			listeCases[x][y].repaint();
			listeCases[x][y].rempli = "2";
			playing++;
			joueur.setText("Tour du joueur 1");
		}
		//Appel de la fontion qui v�rifie si il y a un gagnant � partir du tour 5
		if (playing > 4) {
			Check();
		}
		
	}
	
	//Fonction qui v�rifie si il y a un gagnant
	private static void Check() {
		//V�rification des lignes et colonnes
		for (int i=0; i<3;i++) {
			//Pour le joueur 1
			if ((listeCases[i][0].rempli + listeCases[i][1].rempli + listeCases[i][2].rempli).equals("111") || 
					(listeCases[0][i].rempli + listeCases[1][i].rempli + listeCases[2][i].rempli).equals("111")) {
				GameEnd(1);
			}
			//Pour le joueur 2
			else if ((listeCases[i][0].rempli + listeCases[i][1].rempli + listeCases[i][2].rempli).equals("222") || 
					(listeCases[0][i].rempli + listeCases[1][i].rempli + listeCases[2][i].rempli).equals("222")) {
				GameEnd(2);
			}
			//Appel de la fonction qui termine la partie car le tableau est rempli au tour 9
			else if (playing > 8) {
				GameEnd(0);
			}
		}
		//V�rification des diagonales
		if ((listeCases[0][0].rempli + listeCases[1][1].rempli + listeCases[2][2].rempli).equals("111") ||
				(listeCases[0][2].rempli + listeCases[1][1].rempli + listeCases[2][0].rempli).equals("111")) {
			GameEnd(1);
		}
		else if ((listeCases[0][0].rempli + listeCases[1][1].rempli + listeCases[2][2].rempli).equals("222") ||
				(listeCases[0][2].rempli + listeCases[1][1].rempli + listeCases[2][0].rempli).equals("222")) {
			GameEnd(2);
		}
		//Appel de la fonction qui termine la partie car le tableau est rempli au tour 9
		else if (playing > 8) {
			GameEnd(0);
		}
	}
	
	//Fontcion qui termine la partie
	private static void GameEnd(int g) {
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				listeCases[i][j].EnCours = false;}}
		if (g == 1) {
			joueur.setText("Le joueur 1 gagne !");
		}
		else if (g == 2) {
			joueur.setText("Le joueur 2 gagne !");
		}
		else {
			joueur.setText("Egalit�e !");
		}
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				listeCases[i][j].EnCours = false;}}
		rejouer = new JButton("Rejouer");
		rejouer.setBounds(30, 200, 120, 50);
		rejouer.setBackground(Color.white);
		BufferedImage img = null;
		try {
			img = ImageIO.read(new File("rejouer.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Image dimg = img.getScaledInstance(rejouer.getWidth()/4, rejouer.getHeight()/2,
		        Image.SCALE_SMOOTH);
		rejouer.setIcon(new ImageIcon(dimg));
		rejouer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				Mframe.dispatchEvent(new WindowEvent(Mframe, WindowEvent.WINDOW_CLOSING));
				initWindow();
			}
		});
		MSidePanel.add(rejouer);
		MSidePanel.repaint();
	}
}