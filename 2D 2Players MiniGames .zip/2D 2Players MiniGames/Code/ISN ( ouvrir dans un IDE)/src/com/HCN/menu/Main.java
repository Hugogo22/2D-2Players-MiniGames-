package com.HCN.menu;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

@SuppressWarnings("serial")
public class Main extends JFrame{
	public static JFrame frame;
	public static JPanel panel;
	public static MenuPanel contentPane;
	public static int Window_H = 700;
	public static int Window_W = 900;
	public static Color color = Color.DARK_GRAY;
	
	//Foction ex�cuter d�s le d�but du programme
	public static void main(String[] args) {
		initWindow();
	}
	
	//Fonction cr�ant la fen�tre et la personnalise
	public static void initWindow() {
		//Cr�ation de la fen�tre
		frame = new JFrame();
        frame.setSize(Window_W, Window_H);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Menu Principal");
        contentPane = new MenuPanel(); //Le contentPane est le contenu de la fen�tre
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        
        
        //Cr�ation du menu de personnalisation
        JMenuBar menuBar = new JMenuBar();
		JMenu menu = new JMenu("Param�tres");
		JMenuItem menuMJ = new JMenuItem("Mode Jour");
		JMenuItem menuMN = new JMenuItem("Mode nuit");
		@SuppressWarnings("unused")
		CardLayout cardL = new CardLayout();
		menuBar.add(menu);
		//Ajout des fonctionnalit�s des boutons "Mode jour" / "Mode nuit"
		menuMJ.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				color = Color.DARK_GRAY;
				frame.repaint();
			}
		});
		
		menuMN.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				color = Color.BLACK;
				frame.repaint();
			}
		});
		menu.add(menuMJ);
		menu.add(menuMN);
		frame.setJMenuBar(menuBar);
		frame.setContentPane(contentPane);
	}
}
