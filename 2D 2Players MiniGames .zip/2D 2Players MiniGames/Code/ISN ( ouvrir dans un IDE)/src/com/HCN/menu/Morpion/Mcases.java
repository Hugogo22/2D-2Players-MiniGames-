package com.HCN.menu.Morpion;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

@SuppressWarnings("serial")
public class Mcases extends JPanel implements MouseListener{
	
	String rempli = "0";
	boolean player1 = false;
	boolean player2 = false;
	boolean EnCours = true;
	
	public Mcases(int x,int y) {
		setSize(100, 100);
		setBackground(Color.black);
		
		//Permet de d�tecter un clique sur une case
		addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (EnCours == true) {
					game.CaseClicker(x, y);
					}

		}
		});
	}
	public void paintComponent(Graphics g) {
		g.setColor(Color.DARK_GRAY);
		g.drawRect(0, 0, game.MWindow_W/3-66, game.MWindow_H/3-10);
		//Remplissage des cases avec des croix ou ronds
		if (player1 == true) {
			g.setColor(Color.white);
			g.fillRect(0, 0, game.MWindow_W/3-66, game.MWindow_H/3-10);
			g.setColor(Color.DARK_GRAY);
			g.drawRect(0, 0, game.MWindow_W/3-66, game.MWindow_H/3-10);
			g.drawOval(58, 58, 116, 116);
		}
		else if (player2 == true) {
			g.setColor(Color.white);
			g.fillRect(0, 0, game.MWindow_W/3-66, game.MWindow_H/3-10);
			g.setColor(Color.DARK_GRAY);
			g.drawRect(0, 0, game.MWindow_W/3-66, game.MWindow_H/3-10);
			g.drawLine(58, 58, 174, 174);
			g.drawLine(58, 174, 174, 58);
		}

	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
