package com.HCN.menu;

public abstract class Game extends Thread {
	
	public abstract void init();
	
	public void run() {
		this.init();
	}
}
