package com.HCN.menu.Morpion;

import com.HCN.menu.Game;

public class mainMorpion extends Game{


	public void init() {
		@SuppressWarnings("unused")
		game morpion = new game();

	}

}
