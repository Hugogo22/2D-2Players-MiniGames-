package com.HCN.menu.Pong;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class PlayablePaddle implements KeyListener{

	public void keyPressed(KeyEvent e) {
		int Y = fenetrepong.panel.getJ1Y();
		
		if(e.getKeyCode() == KeyEvent.VK_UP) {
			if(Y >=10) {
			Y -= 10;
			fenetrepong.panel.setJ1Y(Y);
			fenetrepong.panel.repaint();
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_DOWN) {
			if(Y<=470) {
			Y += 10;
			fenetrepong.panel.setJ1Y(Y);
			fenetrepong.panel.repaint();
			}
		}
	}

	public void keyReleased(KeyEvent e) {
		
	}


	public void keyTyped(KeyEvent e) {
		
	}
	

}