package com.HCN.menu.Pong;
import com.HCN.menu.*;
import java.awt.*;
import javax.swing.*;

@SuppressWarnings("serial")
public class Balle extends JPanel {
    private static int cote = 10;

        public void draw(Graphics graphics) {

            //Cr�ation du "design" de la balle
            graphics.fillOval(Main.Window_W / 2 - cote / 2,Main.Window_H / 2 - cote / 2, cote ,cote);
            graphics.setColor(Color.CYAN);

    }
}
