package com.HCN.menu;

public class LeaveMenu extends Game {
	//Permet de correctemennt stopper le programme
	public void init() {
		System.exit(0);
	}

}
